package com.cybage.flight.entities;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonManagedReference;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Flight 
{

	 @Id
	private String flightNumber;
<<<<<<< HEAD
	@NotBlank(message = "Flight name should not be null!")
	@Size(min = 4,max = 15, message = "Flight name should be between 4 to 15 characters!")
	private String flightName;
	@NotBlank(message = "Flight type should not be null!")
	private String flightType;
	@Positive(message = "Flight should have positive numbers of seats!")
	private int totalSeats;
	
	@OneToMany(mappedBy = "flight", cascade = CascadeType.ALL)
	@JsonManagedReference
	private List<FlightSchedule> flightSchedules;
	
=======
	
     @NotBlank(message = "flight name should not be null")
     @Size(min = 4,max = 15, message = "flight should be  min 4 to max 15 character")
	private String flightName;
     
     @NotBlank(message = "flight type should not be null")
	private String flightType;
     
	@Positive(message = "flight should have positive seats")
	private int totalSeats;
	
	
	@OneToMany(mappedBy = "flight", cascade = CascadeType.ALL) // fetch = FetchType.EAGER)  ....changed
	@JsonManagedReference
	private List<FlightSchedule> flightSchedules;
	
	
	
>>>>>>> f232d0969c457faf02e5ef7dbb39b6bce3ab3c9a
}
