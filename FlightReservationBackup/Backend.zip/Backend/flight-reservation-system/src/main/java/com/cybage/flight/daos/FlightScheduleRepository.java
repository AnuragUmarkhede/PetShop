package com.cybage.flight.daos;

import java.sql.Date;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cybage.flight.entities.FlightSchedule;

@Repository
<<<<<<< HEAD
public interface FlightScheduleRepository extends JpaRepository<FlightSchedule, Integer> 
{
	public FlightSchedule findById(int id);

=======
public interface FlightScheduleRepository extends JpaRepository<FlightSchedule, Integer> {

	List<FlightSchedule> findAllBySourceAndDestinationAndDepartureDateAndFlightFlightTypeAndAvailableSeatsGreaterThanEqual(
			String source, String destination, Date departureDate, String flightType, int availableSeats);

	
	public FlightSchedule findById(int id);
	
>>>>>>> f232d0969c457faf02e5ef7dbb39b6bce3ab3c9a
	public void deleteById(int id);
	
	public boolean existsById(int id);
}
