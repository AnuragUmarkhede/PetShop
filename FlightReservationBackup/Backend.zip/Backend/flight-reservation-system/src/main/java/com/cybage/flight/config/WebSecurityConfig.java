package com.cybage.flight.config;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.dao.DaoAuthenticationProvider;
import org.springframework.security.config.annotation.authentication.builders.AuthenticationManagerBuilder;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import javax.servlet.Filter;

import lombok.AllArgsConstructor;

@Configuration
@AllArgsConstructor
@EnableWebSecurity
public class WebSecurityConfig extends WebSecurityConfigurerAdapter {
    
	

    @Autowired
	private CustomJwtAuthenticationFilter customJwtAuthenticationFilter;
    @Autowired
	private JwtAuthenticationEntryPoint jwtAuthenticationEntryPoint;
	
    
    @Override
     protected void configure(HttpSecurity http) throws Exception {
       //Start chain for restricting access.
       http.csrf().disable().authorizeRequests()
       .and()
       //new line
       .cors().disable().authorizeRequests()
         //The following paths…
<<<<<<< HEAD
         .antMatchers("/api/**", "/api/login/**", "/api/registration/**")
=======
         .antMatchers("/api/login/**", "/api/registration/**","/api/passenger/**","/api/flight/**","/api/flightOffer/**","/api/admin/**","/api/search/**","/api/userProfile/**")
>>>>>>> f232d0969c457faf02e5ef7dbb39b6bce3ab3c9a
           // …are accessible to all users (authenticated or not).
           .permitAll()
         //These paths…
         .antMatchers()
           // …are only available to users with ADMIN role.
           .hasRole("ADMIN")
           .antMatchers()
           // …are only available to users with ADMIN role.
           .hasAnyRole("USER","ADMIN")
         // All remaining paths…
        .anyRequest()
          // ...require user to at least be authenticated
          .authenticated()
        .and()
          // If user isn't authorized to access a path...
          .exceptionHandling()
            // ...redirect them to /403
            .accessDeniedPage("/403").authenticationEntryPoint(jwtAuthenticationEntryPoint).
        	and().sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS).
        	and().addFilterBefore(customJwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
       
       
  
     }
    
  
}
