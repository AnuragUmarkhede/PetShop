package com.cybage.flight.entities;


public enum UserRole {
    ROLE_USER,
    ROLE_ADMIN
}
