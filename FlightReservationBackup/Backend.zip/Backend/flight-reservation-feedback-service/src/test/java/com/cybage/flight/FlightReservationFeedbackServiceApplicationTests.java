package com.cybage.flight;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FlightReservationFeedbackServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
